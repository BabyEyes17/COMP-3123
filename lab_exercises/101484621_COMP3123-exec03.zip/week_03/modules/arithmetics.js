function add(a, b) {
    return a + b
}

function subtract(a, b) {
    return a - b
}

const mul = (a, b) => a * b;
const div = (a, b) => a / b;

module.exports = {
    add,
    subtract,
    mul,
    div
};

// console.log(module)
