exports.PORT = 3000;
exports.HOST = 'localhost';

const name = "Jayden Lewis" // this is not exported
const age = "19";
const gender = "Male";

module.exports = {
    age,
    gender
}