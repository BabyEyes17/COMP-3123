const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings']

function lowerCaseWords(array) {

    return new Promise((resolve, reject) => {

        const filteredArray = array
        .filter(item => typeof item === "string")
        .map(str => str.toLowerCase());

        resolve(filteredArray)
    })
}

console.log(lowerCaseWords(mixedArray))