const fs = require('fs');
const path = require('path');
const logsDirectory = path.join(__dirname, 'logs');

if (fs.existsSync(logsDirectory)) {

    fs.readdirSync(logsDirectory).forEach(file => {

        console.log(`${file} has been deleted`);
        fs.unlinkSync(path.join(logsDirectory, file));
    });

    fs.rmdirSync(logsDirectory);

    console.log("Logs directory has been deleted")
}

else { console.log("Logs directory not found") }